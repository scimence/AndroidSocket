﻿
package sci.demo.androidautofit;

import sci.tool.ActivityComponent;
import android.os.Bundle;

/** autofit演示demo主界面 */
public class MainActivity extends ActivityComponent
{
	
	/** 设置界面显示 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("activity_main");
	}
	
	/** 按钮点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if(viewId.equals("btn_connect"))
		{
			ActivityComponent.Show(this, MsgPage.class);
		}
		else if(viewId.equals("btn_close"))
		{
			ActivityComponent.Show(this, MsgPage.class);
		}
		else if(viewId.equals("btn_send"))
		{
			ActivityComponent.Show(this, MsgPage.class);
		}
	}
}
