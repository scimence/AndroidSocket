
package sci.tool;

import java.io.InputStream;
import java.net.InetAddress;
import java.net.Socket;


/** SocketClient.java: ----- 2019-6-18 下午5:36:25 wangzhongyuan */
public class SocketClient
{
	public String ipString = "127.0.0.1";   // 服务器端ip
	public int port = 37280;                // 服务器端口
	
	public Socket socket;
	
	public SocketCallBack print;		// 数据接收方法
	public boolean connected = false;       // 标识当前是否连接到服务器
	public String localIpPort = "";         // 记录本地ip端口信息
	
	public SocketClient(SocketCallBack print, String ipString, int port)
	{
		this.print = print;
		if (ipString != null) this.ipString = ipString;
		if (port >= 0) this.port = port;
	}
	
	public void start()
	{
		try
		{
			if (socket == null)
			{
				InetAddress ip = InetAddress.getByName(ipString);
				socket = new Socket(ip, port);
			}
			
			// 获取其他客户端发送过来的数据
			InputStream inputStream = socket.getInputStream();
			
			byte[] buffer = new byte[1024];
			int len = -1;
			while ((len = inputStream.read(buffer)) != -1)
			{
				String data = new String(buffer, 0, len);
				
				// 通过回调接口将获取到的数据推送出去
				if (print != null)
				{
					print.Print(data);
				}
			}
		}
		catch (Exception ex)
		{
			if (print != null) print.Print("连接服务器失败 " + ex.toString()); // 连接失败
			connected = false;
		}
	}
}
