package sci.tool;

/**  
 * SocketCallBack.java:
 * -----
 * 2019-6-18 下午5:41:56
 * wangzhongyuan 
 */
public abstract class SocketCallBack
{	
	public abstract void Print(String info);
}
