/** Automatically generated file. DO NOT MODIFY */
package sci.demo.androidSocket;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}